import show_files
import main

print("Doing somthing")
print("In another.py, My name is " + __name__)
